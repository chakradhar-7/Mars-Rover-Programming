package mmm;

public interface RoverCommand {
    void execute(Rover rover) ;
}