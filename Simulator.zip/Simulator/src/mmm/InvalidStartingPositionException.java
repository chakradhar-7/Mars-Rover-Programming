package mmm;

public class InvalidStartingPositionException extends Exception {
    private static final long serialVersionUID = 1L;
    public InvalidStartingPositionException(String message) {
        super(message);
    }
}
