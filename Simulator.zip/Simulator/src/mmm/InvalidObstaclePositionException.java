package mmm;

public class InvalidObstaclePositionException extends Exception {
    private static final long serialVersionUID = 1L;

    public InvalidObstaclePositionException(String message) {
        super(message);
    }
}
