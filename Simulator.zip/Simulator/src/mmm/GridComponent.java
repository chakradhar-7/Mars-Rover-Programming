package mmm;

public interface GridComponent {
	void display();

}
